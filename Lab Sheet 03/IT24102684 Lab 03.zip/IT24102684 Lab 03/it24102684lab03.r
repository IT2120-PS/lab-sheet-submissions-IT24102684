
#1#
getwd()

setwd("C:\\Users\\CYBORG 15\\Desktop\\IT24102684 Lab 03")

#2#
student_data <- read.csv("Exercise.csv")

head(student_data)

summary(student_data$X1)

hist(student_data$X1,
     main = "Histogram of Student Age",
     xlab = "Age",
     col = "skyblue",
     border = "black")

#3#
student_data$X2 <- factor(student_data$X2,
                          levels = c(1, 2),
                          labels = c("Male", "Female"))

table(student_data$X2)

barplot(table(student_data$X2),
        main = "Gender Distribution",
        xlab = "Gender",
        ylab = "Frequency",
        col = c("lightgreen", "pink"))

#4#
student_data$X3 <- factor(student_data$X3,
                          levels = c(1, 2, 3),
                          labels = c("Stays at Home", "Boarded Students", "Lodging"))

boxplot(X1 ~ X3,
        data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightblue", "lightgreen", "lightpink"))
